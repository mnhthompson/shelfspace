﻿global using ShelfSpace;
global using ShelfSpace.Data;   // ** Add in later (with db)
// global using ShelfSpace.Extensions;  ** Add in later (with API extensions)

global using Microsoft.AspNetCore.Mvc;
global using Microsoft.EntityFrameworkCore; // authentication
global using System.ComponentModel.DataAnnotations;
global using System.Text.Json.Serialization; //authentication
